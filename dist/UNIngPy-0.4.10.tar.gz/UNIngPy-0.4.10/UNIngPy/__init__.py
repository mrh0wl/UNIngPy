#
#  Este archivo es parte de: UNIngPy.
#
#  UNIngPy es un software libre; puedes redistribuirlo y/o modificarlo
#  esta bajo los términos de la Licencia Pública General GNU publicada por
#  the Free Software Foundation; ya sea la versión 3 de la Licencia, o
#  (a su elección) cualquier versión posterior.
#
#  Para mas informacion acerca de UNIngPy, vea https://github.com/MrH0wl/UNIngPy
#
"""UNIngPy es un paquete para python para obtener los articulos
oficiales de uni.edu.ni
"""

from .UNIngPy import uniarticles